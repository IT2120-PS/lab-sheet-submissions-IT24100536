getwd()
setwd("C://Users//oneDrive//Desktop//IT24100536")
#Q1
#Binomal distribution
pbinom(46, 50, 0.85,lower.tail = FALSE)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15, 12)
